﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppConnection
{
    public partial class InsertRowsForm : Form
    {
        // Свойство для поля Id
        public int Id { get; private set; }

        // Свойство для поля Name
        public string Name { get; private set; }

        // Свойство для поля AltName
        public string AltName { get; private set; }

        // Свойство для поля Iata
        public string Iata { get; private set; }

        // Свойство для поля Icao
        public string Icao { get; private set; }

        // Свойство для поля Callsign
        public string Callsign { get; private set; }

        // Свойство для поля Country
        public string Country { get; private set; }

        // Свойство для поля Active
        public string Active { get; private set; }
        public InsertRowsForm()
        {
            InitializeComponent();
        }

        private void OKbutton_Click(object sender, EventArgs e)
        {
            try
            {
                ConnectionForm.conn.Open();

                string sql = "INSERT INTO airlines (id, name, alt_name, iata, icao, callsign, country, active) VALUES (@id, @name, @altName, @iata, @icao, @callsign, @country, @active);";

                using (NpgsqlCommand cmd = new NpgsqlCommand(sql, ConnectionForm.conn))
                {
                    {
                        // Проверка на валидацию введенного значения Id
                        if (int.TryParse(IdTextBox.Text, out int id))
                        {
                            cmd.Parameters.AddWithValue("id", id);
                        }
                        else
                        {
                            MessageBox.Show("Введите целое число в поле Id!");
                            return;
                        }
                        cmd.Parameters.AddWithValue("id", IdTextBox.Text);
                        cmd.Parameters.AddWithValue("name", NameTextBox.Text);
                        cmd.Parameters.AddWithValue("altName", AltNameTextBox.Text);
                        cmd.Parameters.AddWithValue("iata", IataTextBox.Text);
                        cmd.Parameters.AddWithValue("icao", IcaoTextBox.Text);
                        cmd.Parameters.AddWithValue("callsign", CallsignTextBox.Text);
                        cmd.Parameters.AddWithValue("country", CountryTextBox.Text);
                        cmd.Parameters.AddWithValue("active", ActiveTextBox.Text);

                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Данные успешно добавлены в таблицу airlines!");

                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при вставке данных в таблицу авиакомпаний. Убедитесь, что соединение установлено и открыто.");
            }
            finally
            {
                ConnectionForm.conn.Close();
            }
        }
    }
}
