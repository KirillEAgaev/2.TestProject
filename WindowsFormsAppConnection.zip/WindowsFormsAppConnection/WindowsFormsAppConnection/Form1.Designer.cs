﻿namespace WindowsFormsAppConnection
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.CreateConnection = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ShowTable = new System.Windows.Forms.Button();
            this.InsertRowsButton = new System.Windows.Forms.Button();
            this.DeleteRowsButton = new System.Windows.Forms.Button();
            this.JoinTablesButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // CreateConnection
            // 
            this.CreateConnection.Location = new System.Drawing.Point(21, 32);
            this.CreateConnection.Name = "CreateConnection";
            this.CreateConnection.Size = new System.Drawing.Size(143, 23);
            this.CreateConnection.TabIndex = 0;
            this.CreateConnection.Text = "Create connection";
            this.CreateConnection.UseVisualStyleBackColor = true;
            this.CreateConnection.Click += new System.EventHandler(this.CreateConnection_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Connection";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(232, 45);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(538, 354);
            this.dataGridView1.TabIndex = 2;
            // 
            // ShowTable
            // 
            this.ShowTable.Location = new System.Drawing.Point(21, 75);
            this.ShowTable.Name = "ShowTable";
            this.ShowTable.Size = new System.Drawing.Size(98, 23);
            this.ShowTable.TabIndex = 3;
            this.ShowTable.Text = "Show table";
            this.ShowTable.UseVisualStyleBackColor = true;
            this.ShowTable.Click += new System.EventHandler(this.ShowTable_Click);
            // 
            // InsertRowsButton
            // 
            this.InsertRowsButton.Location = new System.Drawing.Point(21, 121);
            this.InsertRowsButton.Name = "InsertRowsButton";
            this.InsertRowsButton.Size = new System.Drawing.Size(116, 23);
            this.InsertRowsButton.TabIndex = 4;
            this.InsertRowsButton.Text = "INSERT rows";
            this.InsertRowsButton.UseVisualStyleBackColor = true;
            this.InsertRowsButton.Click += new System.EventHandler(this.InsertRowsButton_Click);
            // 
            // DeleteRowsButton
            // 
            this.DeleteRowsButton.Location = new System.Drawing.Point(21, 173);
            this.DeleteRowsButton.Name = "DeleteRowsButton";
            this.DeleteRowsButton.Size = new System.Drawing.Size(116, 23);
            this.DeleteRowsButton.TabIndex = 5;
            this.DeleteRowsButton.Text = "DELETE rows";
            this.DeleteRowsButton.UseVisualStyleBackColor = true;
            this.DeleteRowsButton.Click += new System.EventHandler(this.DeleteRowsButton_Click);
            // 
            // JoinTablesButton
            // 
            this.JoinTablesButton.Location = new System.Drawing.Point(21, 224);
            this.JoinTablesButton.Name = "JoinTablesButton";
            this.JoinTablesButton.Size = new System.Drawing.Size(116, 23);
            this.JoinTablesButton.TabIndex = 6;
            this.JoinTablesButton.Text = "JOIN tables";
            this.JoinTablesButton.UseVisualStyleBackColor = true;
            this.JoinTablesButton.Click += new System.EventHandler(this.JoinTablesButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.JoinTablesButton);
            this.Controls.Add(this.DeleteRowsButton);
            this.Controls.Add(this.InsertRowsButton);
            this.Controls.Add(this.ShowTable);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CreateConnection);
            this.Name = "Form1";
            this.Text = "BD aviation";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CreateConnection;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ShowTable;
        private System.Windows.Forms.Button InsertRowsButton;
        private System.Windows.Forms.Button DeleteRowsButton;
        private System.Windows.Forms.Button JoinTablesButton;
    }
}

