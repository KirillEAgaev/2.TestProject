﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsAppConnection
{
    public partial class Form1 : Form
    {

        private NpgsqlDataAdapter dataAdapter;
        private DataTable dt;
        ConnectionForm myF2 = new ConnectionForm();
        TableForm tableForm = new TableForm();
        InsertRowsForm insertForm = new InsertRowsForm();
        public Form1()
        {
            InitializeComponent();
            dataAdapter = new NpgsqlDataAdapter();
            dt = new DataTable();
        }

        private void CreateConnection_Click(object sender, EventArgs e)
        {
            myF2.ShowDialog();
        }

        private void ShowTable_Click(object sender, EventArgs e)
        {
            tableForm.ShowDialog();
            // Проверяем, что подключение к базе данных уже установлено
            if (ConnectionForm.conn != null)
            {
                string tableName = "";
                if (tableForm.AirportsRadioButton.Checked)
                {
                    tableName = "public.airports;";
                }
                else if (tableForm.AirlinesRadioButton.Checked)
                {
                    tableName = "public.airlines;";
                }
                else if (tableForm.RoutesRadioButton.Checked)
                {
                    tableName = "public.routes;";
                }
                    string query = "SELECT * FROM " + tableName;
                    NpgsqlCommand cmd = new NpgsqlCommand(query, ConnectionForm.conn);
                    NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    // Отобразить результаты запроса в DataGridView
                    dataGridView1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Connection to the database is not established.");
            }
        }

        private void InsertRowsButton_Click(object sender, EventArgs e)
        {
            insertForm.ShowDialog(); // Открываем окно для ввода данных
        }

        private void DeleteRowsButton_Click(object sender, EventArgs e)
        {
            // Получаем индекс выбранной строки в DataGridView
            int selectedIndex = dataGridView1.CurrentCell.RowIndex;
            // Получаем ID выбранной строки
            int id = Convert.ToInt32(dataGridView1.Rows[selectedIndex].Cells["id"].Value);

            // Выполняйте SQL-запрос для удаления выбранной строки из базы данных
            string query = $"DELETE FROM airlines WHERE id = {id}";

            // Выполняем запрос к базе данных.Проверяем активность соединения
            if (ConnectionForm.conn != null)
            {
                ConnectionForm.conn.Open();
                using (NpgsqlCommand command = new NpgsqlCommand(query, ConnectionForm.conn))
                {
                    command.ExecuteNonQuery();
                }

            MessageBox.Show("Выбранная строка успешно удалена из таблицы airlines!");

            }
            else
            {
                MessageBox.Show("Ошибка удаления строки из таблицы авиакомпаний. Убедитесь, что соединение установлено и открыто.");
            }
        }

        private void JoinTablesButton_Click(object sender, EventArgs e)
        {
            try
            {
                ConnectionForm.conn.Open();

                NpgsqlCommand command = new NpgsqlCommand("SELECT a.id, a.callsign, a.country, a.active, r.src_airport, r.dst_airport FROM airlines a JOIN routes r ON a.id = r.airline_id", ConnectionForm.conn);

                dataAdapter.SelectCommand = command;
                dt.Clear();
                dataAdapter.Fill(dt);

                dataGridView1.DataSource = dt;

                ConnectionForm.conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
