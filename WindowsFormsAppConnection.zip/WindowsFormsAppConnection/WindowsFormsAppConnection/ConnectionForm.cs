﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace WindowsFormsAppConnection
{
    public partial class ConnectionForm : Form
    {
        public static NpgsqlConnection conn;

        public ConnectionForm()
        {
            InitializeComponent();
        }

        private void ExecuteConnection_Click(object sender, EventArgs e)
        {
            string connString = $"Host=localhost;Username={txtUsername.Text};Password={txtPassword.Text};Database=flights";
            conn = new NpgsqlConnection(connString);
            try
            {
                conn.Open();
                MessageBox.Show("Connection successful!");
                ExecuteConnection.Enabled = false;
            }
            catch (NpgsqlException ex)
            {
                MessageBox.Show("Connection failed: " + ex.Message);
            }
            finally
            {
                if(conn.State != System.Data.ConnectionState.Closed)
                {
                    conn.Close();
                }
            }
        }

        private void ExecuteDisconnection_Click(object sender, EventArgs e)
        {
            conn.Close();
            MessageBox.Show("Disconnected from the database");
            ExecuteConnection.Enabled = true;
            ExecuteDisconnection.Enabled = false;
        }
    }
}
