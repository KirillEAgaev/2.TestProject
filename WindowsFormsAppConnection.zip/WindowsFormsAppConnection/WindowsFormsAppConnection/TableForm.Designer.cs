﻿namespace WindowsFormsAppConnection
{
    partial class TableForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AirlinesRadioButton = new System.Windows.Forms.RadioButton();
            this.AirportsRadioButton = new System.Windows.Forms.RadioButton();
            this.RoutesRadioButton = new System.Windows.Forms.RadioButton();
            this.OKbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AirlinesRadioButton
            // 
            this.AirlinesRadioButton.AutoSize = true;
            this.AirlinesRadioButton.Checked = true;
            this.AirlinesRadioButton.Location = new System.Drawing.Point(31, 33);
            this.AirlinesRadioButton.Name = "AirlinesRadioButton";
            this.AirlinesRadioButton.Size = new System.Drawing.Size(71, 20);
            this.AirlinesRadioButton.TabIndex = 0;
            this.AirlinesRadioButton.TabStop = true;
            this.AirlinesRadioButton.Text = "airlines";
            this.AirlinesRadioButton.UseVisualStyleBackColor = true;
            // 
            // AirportsRadioButton
            // 
            this.AirportsRadioButton.AutoSize = true;
            this.AirportsRadioButton.Location = new System.Drawing.Point(29, 71);
            this.AirportsRadioButton.Name = "AirportsRadioButton";
            this.AirportsRadioButton.Size = new System.Drawing.Size(73, 20);
            this.AirportsRadioButton.TabIndex = 1;
            this.AirportsRadioButton.TabStop = true;
            this.AirportsRadioButton.Text = "airports";
            this.AirportsRadioButton.UseVisualStyleBackColor = true;
            // 
            // RoutesRadioButton
            // 
            this.RoutesRadioButton.AutoSize = true;
            this.RoutesRadioButton.Location = new System.Drawing.Point(31, 108);
            this.RoutesRadioButton.Name = "RoutesRadioButton";
            this.RoutesRadioButton.Size = new System.Drawing.Size(65, 20);
            this.RoutesRadioButton.TabIndex = 2;
            this.RoutesRadioButton.TabStop = true;
            this.RoutesRadioButton.Text = "routes";
            this.RoutesRadioButton.UseVisualStyleBackColor = true;
            // 
            // OKbutton
            // 
            this.OKbutton.Location = new System.Drawing.Point(152, 165);
            this.OKbutton.Name = "OKbutton";
            this.OKbutton.Size = new System.Drawing.Size(75, 23);
            this.OKbutton.TabIndex = 3;
            this.OKbutton.Text = "OK";
            this.OKbutton.UseVisualStyleBackColor = true;
            this.OKbutton.Click += new System.EventHandler(this.OKbutton_Click);
            // 
            // TableForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(382, 253);
            this.Controls.Add(this.OKbutton);
            this.Controls.Add(this.RoutesRadioButton);
            this.Controls.Add(this.AirportsRadioButton);
            this.Controls.Add(this.AirlinesRadioButton);
            this.Name = "TableForm";
            this.Text = "TableForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button OKbutton;
        public System.Windows.Forms.RadioButton AirlinesRadioButton;
        public System.Windows.Forms.RadioButton AirportsRadioButton;
        public System.Windows.Forms.RadioButton RoutesRadioButton;
    }
}